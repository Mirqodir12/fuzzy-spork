# Tiklash va migratsiya qaydlari

## Asl ZIP bilan taqqoslash

Asl arxiv: funyapi.uz.zip; 449 entry, 16 PHP fayl, ZIP CRC tekshiruvi muvaffaqiyatli. SHA-256: ae0894557046d45bf7ecd11c990f92826cb7d162a9ab16940faed82dc8f7cdec. Asl arxiv Downloads joyida o‘zgarishsiz qoldi.

bot/bot.php 4,479-qator o‘rtasida if($type=="Default" or $type=="default" ifodasida tugaydi. Entry CRC to‘g‘ri bo‘lgani uchun bu ZIP ochishdagi uzilish emas, manba faylning o‘zidagi truncation. To‘liq nusxa Downloads, Codex attachments va joriy workspace ichidan qidirildi; mos to‘liq bot.php topilmadi. Yetishmagan bot kodini taxmin bilan yaratmadik.

ZIP’da quyidagilar yo‘q:

- Root index.php (111111_index.php bor), payme.php, bot/step/, bot/msgs.json, bot/payments.txt va bot/set/usd|rub|inr|try kurs fayllari.
- Bot kutayotgan neworder jadvali va dump’da ko‘rinmagan settings.users, settings.ordercount, users.api_status, users.refnum, users.ban, users.orders ustunlari.
- SQL dump’da real user/order yozuvlari yo‘q. Shuning uchun eski balanslar, to‘lovlar, buyurtmalar ZIP’dan tiklanmaydi. Live DB’ga ulanilmadi.

## Qayta qurilgan sxema

SQLite test sxemasi database/migrations/sqlite/001_initial.sql; MySQL yangi ilova sxemasi database/migrations/mysql/001_initial.sql. Asosiy jadvallar: roles, users, user_roles, accounts, services, orders, ledger_transactions, deposit_requests, login_attempts, support_tickets, settings, audit_logs.

Balans qiymati 1/100 UZS birliklarida signed integer sifatida saqlanadi. Order debiti hisob qoldig‘ini shartli yangilab, order va unique reference ledger qatorini bitta DB transaction ichida yozadi. Depozit tasdig‘i pending so‘rovni bir marta approved qilib, account balance va unique ledger entry’ni transaction ichida yangilaydi. External payment verification implementatsiya qilinmagan.

Test migratsiya runneri faqat CLI + APP_ENV=test + SQLite DSN’ni qabul qiladi; target bevosita ilovaning storage/ papkasida bo‘lishi va oldindan mavjud bo‘lmasligi shart. MySQL fayli ishlab turgan DB’da bajarilmadi.

## Credentiallar

Eski kod ichida Telegram bot token(lar), MySQL paroli va SMS-Activate API kaliti bo‘lgan. Qiymatlarni bu hujjatga yoki qayta qurilgan manbaga ko‘chirmadik. ZIP’ni olgan deb hisoblab:

1. BotFather’da eski bot token(lar)ini revoke/rotate qiling va webhook secret’larni ham yangilang.
2. MySQL parolini rotate qiling, eski user sessiyalarini bekor qiling, DB user’ga eng kam ruxsat bering.
3. SMS provider kalitini revoke qiling va billing/account activity’ni ko‘rib chiqing.
4. Har qanday boshqa oldingi admin, provider, Payme/Paycom kalitlari yoki server parollarini tekshirib, oshkor bo‘lganlarini almashtiring.
5. Yangi deployment uchun faqat yangi tasodifiy DB parolini .env ichida, web-root tashqarisida saqlang. .env.example da haqiqiy credential yo‘q.

## Xavfsiz qayta qurish chegarasi

Bu ZIP legacy Telegram botni qayta tiklamaydi va eski koddan credential/API callback’larini ko‘chirmaydi. Yangi app’da real payment/provider API yoki synthetic social engagement automation yo‘q. Deposit request manual verification uchun; admin tasdig‘i faqat tashqarida haqiqiy tushum tekshirilgandan keyin bajarilishi kerak.

Test natijalari va ishga tushirish yo‘riqnomasi README.md da. MySQL/production tekshiruvi hozircha qolgan ish.
