# FunyAPI ZIP — statik audit

**Sana:** 2026-10-12  
**Ko‘rilgan arxiv:** funyapi.uz.zip (449 entry, 16 PHP fayl)  
**Tekshiruv turi:** manba kodi, SQL sxemasi va server sozlamalarini statik ko‘rish. Hech qanday Telegram, Payme yoki provider so‘rovi yuborilmadi.

## Arxitektura

- PHP sayt/router: .htaccess, 111111_index.php, app/controller/*.php.
- MySQL/MySQLi: app/db.sql; foydalanuvchi sessiyasi va boshqa holatlarning bir qismi bot/user/, bot/number/ kabi fayllarda.
- Telegram bot: bot/bot.php; webhook JSON’i php://input’dan olinadi.
- SMM provider API: provider URL va kalitlari DB’da, buyurtmalarni yaratish/holatini olish kodlari mavjud.
- SMS-Activate API va Payme/Paycom checkout oqimi ham tilga olingan.
- Admin panelning ishlaydigan web backendi topilmadi; admin amallari asosan Telegram bot ichida.
- Composer/dependency manifesti, README, .env.example, migratsiya yoki testlar arxivda yo‘q.

## Muhim topilmalar

### Kritik — ochiq credentiallar va soxta webhook yangilanishi orqali balansga yozish

- Telegram bot tokenlari app/controller/api.php:6 va bot/bot.php:10 da; MySQL paroli app/controller/sql_connect.php:5 da; SMS-Activate kaliti bot/bot.php:12 da kodga qo‘yilgan. Qiymatlarni hisobotga kiritmadim. Bu ZIP tarqatilgan deb hisoblab, Telegram token(lar)ini BotFather orqali bekor qilish, DB parolini va SMS-Activate kalitini almashtirish kerak.
- bot/bot.php:231-250 har qanday POST JSON’ni Telegram update sifatida qabul qiladi; webhook secret header tekshiruvi ko‘rinmadi. bot/bot.php:2704-2712 callback ichidagi ID va summaga tayangan holda balansni oshiradi, shu joyda admin identifikatori tekshirilmaydi. Ochiq webhook manziliga soxta callback yuborish mumkin bo‘lsa, ruxsatsiz balans yozish xavfi bor. Telegram webhook secret token va har bir admin callback uchun server-side admin tekshiruvi talab qilinadi.

### Kritik — botning asosiy fayli kesilgan va sintaksis xatosi bor

- bot/bot.php ZIP ichida 4,479-qatorning o‘rtasida, tugallanmagan if($type==... satrida tugaydi. PHP 8.5.10 lint: Unclosed (, 4479-qator. Faylni taxmin bilan davom ettirish mumkin emas; asl to‘liq nusxa kerak.
- app/controller/avg.php:11 da $d[]=$b?$b:; sintaksis xatosi bor; lint muvaffaqiyatsiz.

### Yuqori — DB dump kod kutayotgan sxemaga mos emas

- app/db.sql da neworder jadvali yo‘q; bot uni yozadi. Bot shuningdek settings.users, settings.ordercount, users.api_status, users.refnum, users.ban va users.orders ustunlarini ishlatadi, lekin dump’dagi tegishli sxemada ular yo‘q.
- users.balance ustuni text sifatida saqlangan, balans o‘zgarishlari uchun ledger/transaction jadvali yo‘q. Bir vaqtda kelgan amallar va qayta yuborilgan callback’lar uchun atomarlik/idempotency kafolati ko‘rinmaydi.
- SQL dump’da real users/orders yozuvlari yo‘q; u asosan sxema va sozlama qatorlarini saqlaydi. Shuning uchun ishlab turgan balans va buyurtmalar ushbu ZIP’dan tiklanmaydi.

### Yuqori — router va to‘lov fayllari arxivda yo‘q

- .htaccess:44 so‘rovlarni index.php’ga rewrite qiladi, ammo arxivda root index.php yo‘q; uning o‘rnida 111111_index.php bor.
- Bot /payme.php’ni checkout yaratish va tekshirish uchun chaqiradi (bot/bot.php:2755-2790), lekin payme.php arxivda yo‘q. payments.txt, msgs.json, bot/step/, hamda bot/set/usd|rub|inr|try kurs fayllari ham topilmadi.
- Depozit tasdig‘i callback’dan kelgan summani ($plus) balansga qo‘shadi (bot/bot.php:2778-2806). To‘lov summasi, valyutasi, foydalanuvchisi va provayderning imzolangan server-side tasdig‘i bilan bog‘lanishi bu arxivda isbotlanmagan; haqiqiy depozitni xavfsiz deb hisoblab bo‘lmaydi.

### Yuqori — tranzaksiya xavfsizligi va SQL

- app/controller/api.php:36-43, 58-92 parametrlarni $_REQUEST’dan oladi, prepared statement ishlatmaydi. Buyurtma provider’ga yuborilgach, balans va bir nechta jadval yangilanadi; DB transaction yoki balansni shartli atomar yechish yo‘q. Parallel so‘rovlar noto‘g‘ri balans/order holatiga olib kelishi mumkin.
- Provider kalitlari URL query string’da yuboriladi (masalan api.php:77, bot/update.php:17); server/proxy loglariga tushishi mumkin. Tashqi HTTP so‘rovlarda timeout/error handling ham yetarli emas.
- bot/bot.php:34-35 TLS peer va hostname tekshiruvlarini o‘chiradi.
- bot/update.php xizmat narxlarini o‘zgartiruvchi cron sifatida ishlaydi, ammo autentifikatsiya/signature talabi ko‘rinmaydi.

### Yuqori — ma’lumotlar ochiqligi va HTML chiqishi

- .htaccess’da app/db.sql, bot/user/, bot/number/, bot/set/ kabi fayllarga bevosita HTTP kirishini bloklaydigan qoida yo‘q. Agar ushbu papka web root bo‘lsa, saqlangan foydalanuvchi holati va to‘lov sozlamalari ochilishi mumkin. Ma’lumot fayllari web root’dan tashqarida turishi kerak.
- app/controller/services.php:271, 340-356 URL’dan va DB/provider’dan olingan qiymatlarni HTML’ga escape qilmasdan chiqaradi; stored/reflected XSS xavfi bor.

## Sintaksis tekshiruvi

PHP 8.5.10 CLI bilan ZIP’dan ajratilgan 16 PHP fayl lint qilindi:

- 12 fayl standart konfiguratsiyada sintaksisdan o‘tdi.
- avg.php va bot.php xato berdi.
- short_open_tag=1 bilan services.php va orders.php o‘tdi; standart sozlamada ular xato berdi. Demak PHP short tags sozlamasiga yashirin bog‘liqlik bor.
- DB bilan integratsion test, Telegram callback testi va to‘lov testi bajarilmadi: credential’lar ochiq/ishonchsiz, provider kodi yo‘q va arxivda to‘liq DB runtime yo‘q.

## Ishga chiqarishdan oldin

1. Ochiq kalit va parollarni bekor qilib yangilang.
2. Asl to‘liq bot.php nusxasini toping; kesilgan faylni taxmin bilan tiklamang.
3. Production DB’dan alohida zaxira oling; ushbu SQL dump’da real user/order ma’lumotlari yo‘q.
4. Admin webhook’iga Telegram secret token tekshiruvi va admin actor ID authorization qo‘shing; balansga yozishni idempotent DB ledger/transaction bilan bajaring.
5. To‘lov provayderining haqiqiy server-side verifikatsiyasi va callback imzosini rasmiy hujjatlar bilan tekshirmaguncha depozitni ishga tushirmang.
6. Sxema migratsiyasini ishlab turgan DB nusxasida tekshiring; jadvallar/ustunlar va code’ni bir xil versiyaga keltiring.
7. index.php routing, ma’lumotlarni web root’dan tashqariga ko‘chirish, HTML escaping va prepared statement’larni tuzating.

## Audit bosqichining chegarasi

Dastlabki audit vaqtida qayta qurish hali bajarilmagan edi. Quyidagi yakuniy qayta qurish bo‘limi keyinroq tayyorlangan xavfsiz alohida web ilovasini, uning testlarini va qolgan cheklovlarni qayd etadi. Original bot, to‘lov callback’i yoki production DB tiklanmagan.


## Qayta qurish va verifikatsiya — 2026-10-12

- Original ZIP CRC bilan tekshirildi; SHA-256: ae0894557046d45bf7ecd11c990f92826cb7d162a9ab16940faed82dc8f7cdec. Arxiv o‘zgarishsiz saqlandi.
- To‘liq bot.php qidiruvi Downloads, Codex attachments va workspace doirasida bajarildi; nusxa topilmadi. bot.php’ni taxmin bilan tiklamadik.
- Izolyatsiyalangan funyapi-audit/rebuilt web ilovasi yaratildi: sessiya autentifikatsiyasi, roles, CSRF, prepared statements, escaping, atomic/idempotent wallet/order operatsiyalari, xizmatlar, support, audit logs, sozlamalar va responsive admin/user pages.
- Yangi kodda legacy ochiq token/parollar yo‘q. .env.example’da faqat almashtiriladigan placeholder credentiallar bor. Eski Telegram token(lar), MySQL paroli va SMS API kaliti uchun rotation talab qilinadi.
- SQLite test sxemasi va test-only migration runneri yaratildi. MySQL DDL ishlab turgan DB’da ishlatilmadi; MySQL integratsiyasi/production deploy tekshirilmagan.
- PHP lint: qayta qurilgan 12 PHP fayl sintaksisdan o‘tdi.
- SQLite biznes/integratsion testlar: 23/23 o‘tdi (idempotency, debit/credit, ledger, ruxsat roli, XSS escaping va UI form actionlari).
- Lokal PHP built-in server HTTP smoke testlari: 44/44 o‘tdi (login, user/admin sahifalari, CSRF rad etilishi, user 403, xizmat yaratish/tahrirlash, order create/detail, manual deposit request, admin CRUD, filters va settings).
- Haqiqiy payment, Telegram bot, tashqi provider, MySQL server va production hosting sinovdan o‘tkazilmadi. Deposit flow faqat pending manual review so‘rovini yozadi; u payment confirmation emas.
- Yakuniy distributiv funyapi-safe-rebuild.zip alohida beriladi; original ZIP ham, production DB ham o‘zgartirilmadi.
