# Legacy holati va yangi DB sxemasi

## ZIP’da yo‘q yoki mos kelmaydigan qismlar

| Qism | ZIP’da kuzatilgan holat | Xavfsiz qaror |
| --- | --- | --- |
| Root index.php | Yo‘q; .htaccess shu faylga rewrite qiladi. 111111_index.php alohida mavjud. | Asl router sifatida taxmin qilinmadi; yangi web app public/index.php bilan alohida qurildi. |
| payme.php | Yo‘q; bot ichida checkout/verifikatsiya uchun chaqiriladi. | To‘lovni taxminan tasdiqlamadik va Payme callback’ini yaratmadik. Yangi wallet faqat manual review request saqlaydi. |
| neworder | app/db.sql’da jadval yo‘q, bot kodida ishlatiladi. | Legacy jadval uchun DDL yoki data import yozilmadi. |
| Legacy users/settings ustunlari | settings.users/ordercount va users.api_status/refnum/ban/orders dump’da mos emas yoki mavjud emas. | Eski schema’ni online o‘zgartirmadik; production connection ishlatilmadi. |
| Live user/order/balance yozuvlari | SQL dump’da yo‘q. | ZIP’dan eski hisoblar tiklanmaydi; ma’lumotni taxmin bilan yaratmadik. |

## Yangi sxema

- roles va user_roles: qat’iy role name va ruxsat bog‘lanishi.
- users/accounts: autentifikatsiya va UZS balansini minor birliklarda saqlash.
- services: qonuniy, ko‘rib chiqilgan xizmatlar katalogi.
- orders: buyurtma holati, unit/total narxi va unique idempotency key.
- ledger_transactions/deposit_requests: immutable reference ledger’i va takrorlanmaydigan manual review tasdig‘i.
- login_attempts, support_tickets, settings, audit_logs: login cheklovi, yordam, konfiguratsiya va audit izi.

## Migratsiya xavfsizligi

database/migrations/sqlite/001_initial.sql test schema. bin/migrate-test.php test-only SQLite runner: production DSN, MySQL DSN, storage papkasidan tashqaridagi path ва mavjud target faylni rad etadi. MySQL DDL yangi schema uchun tayyorlangan, ammo MySQL serverda ishlatilib tekshirilmagan; faqat alohida disposable/staging nusxada tekshirilishi kerak. Production DB’ga hech qanday migratsiya bajarilmadi.

Legacy user, balance yoki order’larni ko‘chirish uchun mapping yo‘q. Ularni import qilish alohida audit, backup, reconciliation va staging test talab qiladi.
