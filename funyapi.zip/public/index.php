<?php
declare(strict_types=1);
require dirname(__DIR__) . '/src/bootstrap.php';

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$user = Auth::current($db);

function post_string(string $key, int $max = 5000): string
{
    $value = trim((string) ($_POST[$key] ?? ''));
    if (strlen($value) > $max) throw new DomainException('One of the submitted fields is too long.');
    return $value;
}
function amount_to_minor(mixed $raw): int
{
    $amount = filter_var($raw, FILTER_VALIDATE_INT);
    if ($amount === false || $amount < 1 || $amount > 1000000000) throw new DomainException('Enter a valid whole UZS amount.');
    return $amount * 100;
}
function require_admin_section(?array $user, string $path): array
{
    $map = [
        '/admin' => ['owner','admin','finance','support'],
        '/admin/users' => ['owner','admin'],
        '/admin/orders' => ['owner','admin','support'],
        '/admin/support' => ['owner','admin','support'],
        '/admin/transactions' => ['owner','admin','finance'],
        '/admin/services' => ['owner','admin'],
        '/admin/settings' => ['owner','admin'],
        '/admin/logs' => ['owner','admin'],
        '/admin/roles' => ['owner'],
    ];
    if (!isset($map[$path])) { http_response_code(404); page('Not found',heading('404','Page not found'),$user); exit; }
    return Auth::requireRole($user,$map[$path]);
}

if ($method === 'POST') {
    require_csrf();
    try {
        if ($path === '/login') {
            if (Auth::login($db,post_string('email',190), (string)($_POST['password']??''), (string)($_SERVER['REMOTE_ADDR']??'unknown')) === null) {
                render_login('The credentials were not accepted. If you have tried several times, wait 15 minutes and try again.'); exit;
            }
            redirect('/');
        }
        if ($path === '/register') {
            if (setting($db,'registration_open','1') !== '1') throw new DomainException('Registration is currently closed.');
            $id=Auth::register($db,post_string('email',190),post_string('display_name',160),(string)($_POST['password']??''));
            session_regenerate_id(true); $_SESSION['_csrf']=bin2hex(random_bytes(32)); $_SESSION['user_id']=$id;
            Domain::audit($db,$id,'user.registered','user',$id,[]);
            redirect('/');
        }
        if ($path === '/logout') { unset($_SESSION['user_id'],$_SESSION['_csrf']); session_regenerate_id(true); redirect('/login'); }
        $actor=Auth::requireLogin($user);
        if ($path === '/orders/create') {
            $service=(int)($_POST['service_id']??0); $quantity=filter_var($_POST['quantity']??null,FILTER_VALIDATE_INT);
            if ($quantity===false) throw new DomainException('Enter a valid quantity.');
            $orderId=Domain::placeOrder($db,(int)$actor['id'],$service,(int)$quantity,post_string('details',1500),post_string('_key',64));
            flash('success','Order submitted. Reference #' . $orderId . '.'); redirect('/orders/' . $orderId);
        }
        if ($path === '/wallet/deposit') {
            $id=Domain::requestDeposit($db,(int)$actor['id'],amount_to_minor($_POST['amount']??null),post_string('note',500),post_string('_key',64));
            flash('success','Deposit request #' . $id . ' was submitted for manual review.'); redirect('/wallet');
        }
        if ($path === '/profile') {
            $name=post_string('display_name',160);
            if ($name==='' || mb_strlen($name)>80) throw new DomainException('Name must be between 1 and 80 characters.');
            $stmt=$db->prepare('UPDATE users SET display_name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?'); $stmt->execute([$name,(int)$actor['id']]);
            Domain::audit($db,(int)$actor['id'],'profile.updated','user',(int)$actor['id'],[]); flash('success','Profile updated.'); redirect('/profile');
        }
        if ($path === '/help') {
            $subject=post_string('subject',200); $message=post_string('message',3000);
            if($subject===''||$message==='') throw new DomainException('Add a subject and message.');
            $stmt=$db->prepare('INSERT INTO support_tickets(user_id,subject,message,status,created_at,updated_at) VALUES(?,?,?, ?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)');
            $stmt->execute([(int)$actor['id'],$subject,$message,'open']); $id=(int)$db->lastInsertId(); Domain::audit($db,(int)$actor['id'],'support.created','support_ticket',$id,[]); flash('success','Your support request was sent.'); redirect('/help');
        }
        if (str_starts_with($path,'/admin/')) {
            $roleMap=[
                '/admin/services/create'=>['owner','admin'], '/admin/services/update'=>['owner','admin'], '/admin/services/toggle'=>['owner','admin'],
                '/admin/user/role'=>['owner'], '/admin/user/adjust'=>['owner','admin','finance'], '/admin/user/status'=>['owner','admin'],
                '/admin/order/status'=>['owner','admin','support'], '/admin/deposit/approve'=>['owner','admin','finance'], '/admin/deposit/reject'=>['owner','admin','finance'],
                '/admin/settings'=>['owner','admin'], '/admin/ticket/status'=>['owner','admin','support']
            ];
            if (!isset($roleMap[$path])) { http_response_code(404); page('Not found',heading('404','Page not found'),$actor); exit; }
            Auth::requireRole($actor,$roleMap[$path]); $uid=(int)$actor['id'];
            if($path==='/admin/services/create'){
                $price=amount_to_minor($_POST['price']??null); $id=Domain::createService($db,['name'=>post_string('name',120),'category'=>post_string('category',100),'description'=>post_string('description',2000),'unit_price_minor'=>$price],$uid);
                flash('success','Service published as #' . $id . '.'); redirect('/admin/services');
            }
            if($path==='/admin/services/update'){
                $price=amount_to_minor($_POST['price']??null);
                Domain::updateService($db,(int)($_POST['service_id']??0),['name'=>post_string('name',120),'category'=>post_string('category',100),'description'=>post_string('description',2000),'unit_price_minor'=>$price],$uid);
                flash('success','Service details and price updated.'); redirect('/admin/services');
            }
            if($path==='/admin/services/toggle'){Domain::setServiceActive($db,(int)($_POST['service_id']??0),(string)($_POST['active']??'0')==='1',$uid);flash('success','Service availability updated.');redirect('/admin/services');}
            if($path==='/admin/user/role'){
                $target=(int)($_POST['user_id']??0); $role=post_string('role',40);
                if(!in_array($role,['admin','finance','support','user'],true))throw new DomainException('That role cannot be assigned here.');
                if($target===$uid)throw new DomainException('You cannot change your own role.');
                $check=$db->prepare('SELECT id FROM users WHERE id=?');$check->execute([$target]);if(!$check->fetchColumn())throw new DomainException('User not found.');
                $db->beginTransaction();try{$db->prepare('DELETE FROM user_roles WHERE user_id=?')->execute([$target]);$db->prepare('INSERT INTO user_roles(user_id,role_id) SELECT ?,id FROM roles WHERE name=?')->execute([$target,$role]);$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
                Domain::audit($db,$uid,'user.role_changed','user',$target,['role'=>$role]);flash('success','User role updated.');redirect('/admin/users');
            }
            if($path==='/admin/user/adjust'){$target=(int)($_POST['user_id']??0);$raw=filter_var($_POST['amount']??null,FILTER_VALIDATE_INT);if($raw===false||$raw===0)throw new DomainException('Enter a non-zero whole UZS adjustment.');$minor=$raw*100;Domain::adjustBalance($db,$target,$minor,post_string('reason',500),$uid,post_string('_key',64));flash('success','Balance adjustment recorded in the ledger.');redirect('/admin/users');}
            if($path==='/admin/user/status'){$target=(int)($_POST['user_id']??0);$status=post_string('status',20);if(!in_array($status,['active','suspended'],true)||$target===$uid)throw new DomainException('That status change is not allowed.');$owner=$db->prepare('SELECT COUNT(*) FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=? AND r.name=?');$owner->execute([$target,'owner']);if((int)$owner->fetchColumn()>0)throw new DomainException('Owner accounts cannot be suspended from this panel.');$stmt=$db->prepare('UPDATE users SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$stmt->execute([$status,$target]);Domain::audit($db,$uid,'user.status_changed','user',$target,['status'=>$status]);flash('success','User status updated.');redirect('/admin/users');}
            if($path==='/admin/order/status'){Domain::changeOrderStatus($db,(int)($_POST['order_id']??0),str_replace(' ','_',post_string('status',30)),$uid);flash('success','Order status updated.');redirect('/admin/orders');}
            if($path==='/admin/deposit/approve'){Domain::approveDeposit($db,(int)($_POST['request_id']??0),$uid);flash('success','Request marked verified and credited to the internal ledger.');redirect('/admin/transactions');}
            if($path==='/admin/deposit/reject'){Domain::rejectDeposit($db,(int)($_POST['request_id']??0),$uid,post_string('note',500));flash('success','Deposit request rejected.');redirect('/admin/transactions');}
            if($path==='/admin/settings'){$registration=(string)($_POST['registration_open']??'0');$email=post_string('support_email',190);if(!in_array($registration,['0','1'],true)||!filter_var($email,FILTER_VALIDATE_EMAIL))throw new DomainException('Check the registration setting and support email.');foreach(['registration_open'=>$registration,'support_email'=>$email] as $key=>$value){if($db->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql'){$stmt=$db->prepare('INSERT INTO settings(setting_key,setting_value,updated_by,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_by=VALUES(updated_by),updated_at=CURRENT_TIMESTAMP');}else{$stmt=$db->prepare('INSERT INTO settings(setting_key,setting_value,updated_by,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP');}$stmt->execute([$key,$value,$uid]);}Domain::audit($db,$uid,'settings.updated','settings',null,[]);flash('success','Settings saved.');redirect('/admin/settings');}
            if($path==='/admin/ticket/status'){$id=(int)($_POST['ticket_id']??0);$status=post_string('status',30);if(!in_array($status,['open','in_progress','closed'],true))throw new DomainException('Choose a valid ticket status.');$stmt=$db->prepare('UPDATE support_tickets SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$stmt->execute([$status,$id]);Domain::audit($db,$uid,'support.status_changed','support_ticket',$id,['status'=>$status]);flash('success','Support request updated.');redirect('/admin/support');}
        }
        http_response_code(404); page('Not found',heading('404','Page not found'),$actor);
    } catch (DomainException $e) {
        flash('error',$e->getMessage());
        if(str_starts_with($path,'/admin/')) redirect('/admin');
        if($path==='/profile')redirect('/profile'); if($path==='/wallet/deposit')redirect('/wallet'); if($path==='/help')redirect('/help'); if($path==='/orders/create')redirect('/services'); if($path==='/register') { render_register($db,$e->getMessage()); exit; }
        redirect('/');
    } catch (Throwable $e) {
        error_log('Request failed: ' . $e->getMessage()); http_response_code(500); page('Request failed','<section class="panel"><h1>We could not complete that action</h1><p class="muted">Please retry later or contact support. The event was recorded in the server log.</p></section>',$user);
    }
}

if ($path==='/login') { render_login(); exit; }
if ($path==='/register') { if(setting($db,'registration_open','1')!=='1'){http_response_code(403);page('Registration closed',heading('ACCOUNT','Registration is closed'));exit;}render_register($db);exit; }
if ($path==='/') { $user=Auth::requireLogin($user); render_dashboard($db,$user); exit; }
$user=Auth::requireLogin($user);
if($path==='/services'){render_services($db,$user);exit;}
if(preg_match('#^/services/(\d+)$#',$path,$m)){render_service($db,$user,(int)$m[1]);exit;}
if($path==='/orders'){render_orders($db,$user);exit;}
if(preg_match('#^/orders/(\d+)$#',$path,$m)){render_order_detail($db,$user,(int)$m[1]);exit;}
if($path==='/wallet'){render_wallet($db,$user);exit;}
if($path==='/profile'){render_profile($db,$user);exit;}
if($path==='/admin/support'){$admin=require_admin_section($user,$path);render_admin($db,$admin,$path);exit;}
if($path==='/help'){render_help($db,$user);exit;}
if(str_starts_with($path,'/admin')){$admin=require_admin_section($user,$path);render_admin($db,$admin,$path);exit;}
http_response_code(404);page('Not found',heading('404','Page not found','The page you requested does not exist.'),$user);
