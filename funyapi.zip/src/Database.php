<?php
declare(strict_types=1);

final class Database
{
    public static function connect(): PDO
    {
        $dsn = Config::get('APP_DSN');
        if ($dsn === null) {
            throw new RuntimeException('APP_DSN is required. Copy .env.example to .env and configure the database.');
        }
        $user = Config::get('DB_USER');
        $password = Config::get('DB_PASSWORD');
        $pdo = new PDO($dsn, $user, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA busy_timeout = 5000');
        }
        return $pdo;
    }
}
