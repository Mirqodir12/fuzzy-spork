<?php
declare(strict_types=1);

final class Domain
{
    private const CATEGORIES = ['Design', 'Content production', 'Consulting', 'Advertising', 'Other reviewed service'];
    private const ORDER_STATUSES = ['pending', 'in_progress', 'completed', 'canceled'];
    private const BLOCKED_TERMS = ['followers', 'follower', 'subscribers', 'subscriber', 'subscribe', 'likes', 'views', 'comments', 'engagement', 'nakrutka', 'накрут', 'подпис', 'лайк', 'просмотр', 'комментар', 'репост', 'obunachi', 'obunach', 'layk'];

    public static function categories(): array
    {
        return self::CATEGORIES;
    }

    public static function validateServiceText(string $name, string $description): void
    {
        $text = mb_strtolower($name . ' ' . $description);
        foreach (self::BLOCKED_TERMS as $term) {
            if (mb_stripos($text, $term) !== false) {
                throw new DomainException('This catalog is for lawful, human-delivered services. The requested service wording is not allowed.');
            }
        }
    }

    public static function createService(PDO $db, array $input, int $actor): int
    {
        $name = trim((string) ($input['name'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));
        $category = (string) ($input['category'] ?? '');
        $price = filter_var($input['unit_price_minor'] ?? null, FILTER_VALIDATE_INT);
        if ($name === '' || mb_strlen($name) > 100 || mb_strlen($description) > 2000) {
            throw new DomainException('Add a service name (up to 100 characters) and a description (up to 2,000 characters).');
        }
        if (!in_array($category, self::CATEGORIES, true) || $price === false || $price < 1 || $price > 100000000000) {
            throw new DomainException('Choose a service category and a valid unit price.');
        }
        self::validateServiceText($name, $description);
        $stmt = $db->prepare('INSERT INTO services (name, category, description, unit_price_minor, currency, active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
        $stmt->execute([$name, $category, $description, $price, 'UZS']);
        $id = (int) $db->lastInsertId();
        self::audit($db, $actor, 'service.created', 'service', $id, ['category' => $category]);
        return $id;
    }

    public static function setServiceActive(PDO $db, int $serviceId, bool $active, int $actor): void
    {
        $stmt = $db->prepare('UPDATE services SET active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$active ? 1 : 0, $serviceId]);
        if ($stmt->rowCount() !== 1) {
            throw new DomainException('Service not found.');
        }
        self::audit($db, $actor, $active ? 'service.activated' : 'service.paused', 'service', $serviceId, []);
    }

    public static function updateService(PDO $db, int $serviceId, array $input, int $actor): void
    {
        $name = trim((string) ($input['name'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));
        $category = (string) ($input['category'] ?? '');
        $price = filter_var($input['unit_price_minor'] ?? null, FILTER_VALIDATE_INT);
        if ($name === '' || mb_strlen($name) > 100 || mb_strlen($description) > 2000) {
            throw new DomainException('Add a service name (up to 100 characters) and a description (up to 2,000 characters).');
        }
        if (!in_array($category, self::CATEGORIES, true) || $price === false || $price < 1 || $price > 100000000000) {
            throw new DomainException('Choose a service category and a valid unit price.');
        }
        self::validateServiceText($name, $description);
        $exists = $db->prepare('SELECT id FROM services WHERE id = ?');
        $exists->execute([$serviceId]);
        if ($exists->fetchColumn() === false) {
            throw new DomainException('Service not found.');
        }
        $stmt = $db->prepare('UPDATE services SET name = ?, category = ?, description = ?, unit_price_minor = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$name, $category, $description, $price, $serviceId]);
        self::audit($db, $actor, 'service.updated', 'service', $serviceId, ['category' => $category, 'unit_price_minor' => $price]);
    }

    public static function balance(PDO $db, int $userId): int
    {
        $stmt = $db->prepare('SELECT balance_minor FROM accounts WHERE user_id = ?');
        $stmt->execute([$userId]);
        $value = $stmt->fetchColumn();
        return $value === false ? 0 : (int) $value;
    }

    public static function placeOrder(PDO $db, int $userId, int $serviceId, int $quantity, string $details, string $key): int
    {
        if ($quantity < 1 || $quantity > 100000 || mb_strlen($details) > 1500 || !preg_match('/^[a-f0-9]{32,64}$/', $key)) {
            throw new DomainException('Check the quantity and order details.');
        }
        $existing = $db->prepare('SELECT id FROM orders WHERE idempotency_key = ? AND user_id = ?');
        $existing->execute([$key, $userId]);
        $existingId = $existing->fetchColumn();
        if ($existingId !== false) {
            return (int) $existingId;
        }
        $serviceQuery = $db->prepare('SELECT id, unit_price_minor, currency FROM services WHERE id = ? AND active = 1');
        $serviceQuery->execute([$serviceId]);
        $service = $serviceQuery->fetch();
        if (!$service) {
            throw new DomainException('That service is unavailable.');
        }
        $unit = (int) $service['unit_price_minor'];
        if ($unit < 1 || $quantity > intdiv(PHP_INT_MAX, $unit)) {
            throw new DomainException('The order amount is invalid.');
        }
        $total = $unit * $quantity;
        $db->beginTransaction();
        try {
            $debit = $db->prepare('UPDATE accounts SET balance_minor = balance_minor - ? WHERE user_id = ? AND balance_minor >= ?');
            $debit->execute([$total, $userId, $total]);
            if ($debit->rowCount() !== 1) {
                throw new DomainException('Your available balance is too low.');
            }
            $publicId = bin2hex(random_bytes(8));
            $insert = $db->prepare('INSERT INTO orders (public_id, user_id, service_id, quantity, unit_price_minor, total_minor, currency, details, status, idempotency_key, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
            $insert->execute([$publicId, $userId, $serviceId, $quantity, $unit, $total, $service['currency'], $details, 'pending', $key]);
            $orderId = (int) $db->lastInsertId();
            $ledger = $db->prepare('INSERT INTO ledger_transactions (user_id, type, amount_minor, currency, reference, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
            $ledger->execute([$userId, 'order_charge', -$total, $service['currency'], 'order:' . $orderId, 'Order ' . $publicId, $userId]);
            self::audit($db, $userId, 'order.created', 'order', $orderId, ['total_minor' => $total]);
            $db->commit();
            return $orderId;
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($e instanceof PDOException) {
                $existing->execute([$key, $userId]);
                $duplicate = $existing->fetchColumn();
                if ($duplicate !== false) {
                    return (int) $duplicate;
                }
            }
            throw $e;
        }
    }

    public static function requestDeposit(PDO $db, int $userId, int $amountMinor, string $note, string $key): int
    {
        if ($amountMinor < 10000 || $amountMinor > 5000000000 || mb_strlen($note) > 500 || !preg_match('/^[a-f0-9]{32,64}$/', $key)) {
            throw new DomainException('Enter a valid amount (100 UZS to 50,000,000 UZS) and optional note.');
        }
        $stmt = $db->prepare('INSERT INTO deposit_requests (user_id, amount_minor, currency, status, user_note, idempotency_key, created_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        try {
            $stmt->execute([$userId, $amountMinor, 'UZS', 'pending', $note, $key]);
            $id = (int) $db->lastInsertId();
            self::audit($db, $userId, 'deposit.requested', 'deposit_request', $id, ['amount_minor' => $amountMinor]);
            return $id;
        } catch (PDOException $e) {
            $find = $db->prepare('SELECT id FROM deposit_requests WHERE user_id = ? AND idempotency_key = ?');
            $find->execute([$userId, $key]);
            $existing = $find->fetchColumn();
            if ($existing !== false) {
                return (int) $existing;
            }
            throw $e;
        }
    }

    public static function approveDeposit(PDO $db, int $requestId, int $actor): void
    {
        $db->beginTransaction();
        try {
            $sql = 'SELECT id, user_id, amount_minor, currency, status FROM deposit_requests WHERE id = ?';
            if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
                $sql .= ' FOR UPDATE';
            }
            $query = $db->prepare($sql);
            $query->execute([$requestId]);
            $request = $query->fetch();
            if (!$request) {
                throw new DomainException('Deposit request not found.');
            }
            if ($request['status'] === 'approved') {
                $db->commit();
                return;
            }
            if ($request['status'] !== 'pending') {
                throw new DomainException('This request has already been reviewed.');
            }
            $accountSql = 'SELECT balance_minor FROM accounts WHERE user_id = ?';
            if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
                $accountSql .= ' FOR UPDATE';
            }
            $accountQuery = $db->prepare($accountSql);
            $accountQuery->execute([(int) $request['user_id']]);
            $currentBalance = $accountQuery->fetchColumn();
            $credit = (int) $request['amount_minor'];
            if ($currentBalance === false || (int) $currentBalance > PHP_INT_MAX - $credit) {
                throw new DomainException('The account is missing or the credit exceeds its safe limit.');
            }
            $updateBalance = $db->prepare('UPDATE accounts SET balance_minor = balance_minor + ? WHERE user_id = ?');
            $updateBalance->execute([$credit, (int) $request['user_id']]);
            if ($updateBalance->rowCount() !== 1) {
                throw new DomainException('The account balance could not be updated.');
            }
            $reference = 'deposit:' . $requestId;
            $ledger = $db->prepare('INSERT INTO ledger_transactions (user_id, type, amount_minor, currency, reference, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
            $ledger->execute([(int) $request['user_id'], 'deposit_credit', (int) $request['amount_minor'], $request['currency'], $reference, 'Verified manually by finance', $actor]);
            $update = $db->prepare('UPDATE deposit_requests SET status = ?, review_note = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ? AND status = ?');
            $update->execute(['approved', 'Verified manually outside this application', $actor, $requestId, 'pending']);
            if ($update->rowCount() !== 1) {
                throw new DomainException('This request has already been reviewed.');
            }
            self::audit($db, $actor, 'deposit.approved', 'deposit_request', $requestId, ['amount_minor' => (int) $request['amount_minor']]);
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }

    public static function rejectDeposit(PDO $db, int $requestId, int $actor, string $note): void
    {
        $stmt = $db->prepare('UPDATE deposit_requests SET status = ?, review_note = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ? AND status = ?');
        $stmt->execute(['rejected', mb_substr(trim($note), 0, 500), $actor, $requestId, 'pending']);
        if ($stmt->rowCount() !== 1) {
            throw new DomainException('Request not found or already reviewed.');
        }
        self::audit($db, $actor, 'deposit.rejected', 'deposit_request', $requestId, []);
    }

    public static function adjustBalance(PDO $db, int $userId, int $amountMinor, string $reason, int $actor, string $key): void
    {
        if ($amountMinor === 0 || abs($amountMinor) > 5000000000 || trim($reason) === '' || mb_strlen($reason) > 500 || !preg_match('/^[a-f0-9]{32,64}$/', $key)) {
            throw new DomainException('Enter a non-zero adjustment, a reason, and a valid request token.');
        }
        $db->beginTransaction();
        try {
            if ($amountMinor > 0) {
                $current = $db->prepare('SELECT balance_minor FROM accounts WHERE user_id = ?');
                $current->execute([$userId]);
                $balance = $current->fetchColumn();
                if ($balance === false || (int) $balance > PHP_INT_MAX - $amountMinor) {
                    throw new DomainException('Account is missing or the credit exceeds its safe limit.');
                }
            }
            if ($amountMinor < 0) {
                $stmt = $db->prepare('UPDATE accounts SET balance_minor = balance_minor + ? WHERE user_id = ? AND balance_minor >= ?');
                $stmt->execute([$amountMinor, $userId, abs($amountMinor)]);
            } else {
                $stmt = $db->prepare('UPDATE accounts SET balance_minor = balance_minor + ? WHERE user_id = ?');
                $stmt->execute([$amountMinor, $userId]);
            }
            if ($stmt->rowCount() !== 1) {
                throw new DomainException('Account not found or debit exceeds available balance.');
            }
            $ref = 'adjustment:' . $key;
            $ledger = $db->prepare('INSERT INTO ledger_transactions (user_id, type, amount_minor, currency, reference, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
            $ledger->execute([$userId, $amountMinor > 0 ? 'admin_credit' : 'admin_debit', $amountMinor, 'UZS', $ref, trim($reason), $actor,]);
            self::audit($db, $actor, 'account.adjusted', 'user', $userId, ['amount_minor' => $amountMinor, 'reason' => trim($reason)]);
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($e instanceof PDOException && str_contains(strtolower($e->getMessage()), 'unique')) {
                return;
            }
            throw $e;
        }
    }

    public static function changeOrderStatus(PDO $db, int $orderId, string $status, int $actor): void
    {
        if (!in_array($status, self::ORDER_STATUSES, true)) {
            throw new DomainException('Choose a valid order status.');
        }
        $exists = $db->prepare('SELECT id FROM orders WHERE id = ?');
        $exists->execute([$orderId]);
        if ($exists->fetchColumn() === false) {
            throw new DomainException('Order not found.');
        }
        $stmt = $db->prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$status, $orderId]);
        self::audit($db, $actor, 'order.status_changed', 'order', $orderId, ['status' => $status]);
    }

    public static function audit(PDO $db, ?int $actor, string $action, string $entityType, ?int $entityId, array $metadata): void
    {
        $stmt = $db->prepare('INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)');
        $stmt->execute([$actor, $action, $entityType, $entityId, json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
    }
}
