<?php
declare(strict_types=1);

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function require_csrf(): void
{
    $given = (string) ($_POST['_csrf'] ?? '');
    $known = (string) ($_SESSION['_csrf'] ?? '');
    if ($given === '' || $known === '' || !hash_equals($known, $given)) {
        http_response_code(419);
        exit('The form expired. Reload and try again.');
    }
}

function redirect(string $path): never
{
    header('Location: ' . $path, true, 303);
    exit;
}

function flash(string $kind, string $message): void
{
    $_SESSION['_flash'][] = ['kind' => $kind, 'message' => $message];
}

function take_flashes(): array
{
    $items = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return is_array($items) ? $items : [];
}

function money(int $minor, string $currency = 'UZS'): string
{
    return number_format($minor / 100, 2, '.', ' ') . ' ' . $currency;
}

function page(string $title, string $body, ?array $user = null): void
{
    $appName = Config::get('APP_NAME', 'Funy Services');
    $flashes = take_flashes();
    $nav = '';
    if ($user !== null) {
        $links = [
            '/' => 'Dashboard',
            '/services' => 'Services',
            '/orders' => 'Orders',
            '/wallet' => 'Balance & history',
            '/profile' => 'Profile',
            '/help' => 'Help',
        ];
        if (Auth::hasAnyRole($user, ['owner', 'admin', 'finance', 'support'])) {
            $links['/admin'] = 'Admin';
        }
        foreach ($links as $url => $label) {
            $nav .= '<a href="' . e($url) . '">' . e($label) . '</a>';
        }
        $nav .= '<form class="nav-logout" method="post" action="/logout">' . csrf_field() . '<button class="link-button" type="submit">Sign out</button></form>';
    }
    $flashHtml = '';
    foreach ($flashes as $item) {
        $flashHtml .= '<div class="notice notice-' . e($item['kind']) . '">' . e($item['message']) . '</div>';
    }
    $authLink = $user === null ? '<a href="/login">Sign in</a><a class="button button-primary" href="/register">Create account</a>' : '<span class="user-chip">' . e($user['display_name']) . '</span>';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="light"><title>' . e($title) . ' · ' . e($appName) . '</title><link rel="stylesheet" href="/assets/app.css"></head><body><header class="topbar"><a class="brand" href="/">' . e($appName) . '</a><nav class="topnav">' . $nav . '</nav><div class="top-actions">' . $authLink . '</div></header><main class="shell"><div class="flash-stack">' . $flashHtml . '</div>' . $body . '</main><footer class="footer">' . e($appName) . ' · Account and order workspace</footer></body></html>';
}

function form_start(string $action, string $class = ''): string
{
    return '<form method="post" action="' . e($action) . '" class="' . e($class) . '">' . csrf_field();
}
