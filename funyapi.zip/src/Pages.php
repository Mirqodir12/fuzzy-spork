<?php
declare(strict_types=1);

function query_rows(PDO $db, string $sql, array $params = []): array
{
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function query_value(PDO $db, string $sql, array $params = []): mixed
{
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

function setting(PDO $db, string $key, string $default = ''): string
{
    $value = query_value($db, 'SELECT setting_value FROM settings WHERE setting_key = ?', [$key]);
    return $value === false ? $default : (string) $value;
}

function heading(string $eyebrow, string $title, string $description = '', string $action = ''): string
{
    return '<div class="page-heading"><div><p class="eyebrow">' . e($eyebrow) . '</p><h1>' . e($title) . '</h1><p class="muted">' . e($description) . '</p></div>' . $action . '</div>';
}

function pill(string $value): string
{
    $safe = strtolower(preg_replace('/[^a-z0-9_-]/i', '-', $value) ?? '');
    return '<span class="pill pill-' . e($safe) . '">' . e(str_replace('_', ' ', $value)) . '</span>';
}

function admin_nav(): string
{
    $items = ['/admin'=>'Overview','/admin/users'=>'Users','/admin/orders'=>'Orders','/admin/transactions'=>'Transactions','/admin/services'=>'Services','/admin/support'=>'Support','/admin/settings'=>'Settings','/admin/logs'=>'Logs','/admin/roles'=>'Roles'];
    $html = '<nav class="admin-nav">';
    foreach ($items as $url=>$label) $html .= '<a href="' . e($url) . '">' . e($label) . '</a>';
    return $html . '</nav>';
}

function render_login(string $error = ''): void
{
    $body = heading('WELCOME BACK','Sign in','Access your account and service workspace.') . '<section class="panel auth-panel">' . ($error ? '<div class="notice notice-error">' . e($error) . '</div>' : '') . form_start('/login') . '<label>Email<input type="email" name="email" maxlength="190" autocomplete="email" required></label><label>Password<input type="password" name="password" autocomplete="current-password" required></label><button class="button button-primary" type="submit">Sign in</button></form><p class="muted">New here? <a href="/register">Create an account</a></p></section>';
    page('Sign in', $body);
}

function render_register(PDO $db, string $error = ''): void
{
    $body = heading('GET STARTED','Create your account','A secure workspace for reviewed services and order tracking.') . '<section class="panel auth-panel">' . ($error ? '<div class="notice notice-error">' . e($error) . '</div>' : '') . form_start('/register') . '<label>Your name<input name="display_name" maxlength="80" autocomplete="name" required></label><label>Email<input type="email" name="email" maxlength="190" autocomplete="email" required></label><label>Password<input type="password" name="password" minlength="12" autocomplete="new-password" required><small>Use at least 12 characters.</small></label><button class="button button-primary" type="submit">Create account</button></form><p class="muted">Already registered? <a href="/login">Sign in</a></p></section>';
    page('Create account', $body);
}

function render_dashboard(PDO $db, array $user): void
{
    $balance = Domain::balance($db, (int) $user['id']);
    $orders = (int) query_value($db, 'SELECT COUNT(*) FROM orders WHERE user_id = ?', [(int) $user['id']]);
    $activeServices = (int) query_value($db, 'SELECT COUNT(*) FROM services WHERE active = 1');
    $recent = query_rows($db, 'SELECT o.id,o.public_id,o.status,o.total_minor,o.currency,o.created_at,s.name service_name FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 5', [(int) $user['id']]);
    $body = heading('ACCOUNT OVERVIEW','Hello, ' . $user['display_name'],'Track orders, find reviewed services and manage your account.','<a class="button button-primary" href="/services">Browse services</a>');
    $body .= '<div class="metric-grid"><article class="metric-card"><span>Available balance</span><strong>' . e(money($balance)) . '</strong><a href="/wallet">Open wallet →</a></article><article class="metric-card"><span>Your orders</span><strong>' . e((string) $orders) . '</strong><a href="/orders">View orders →</a></article><article class="metric-card"><span>Reviewed services</span><strong>' . e((string) $activeServices) . '</strong><a href="/services">Browse catalog →</a></article></div>';
    $body .= '<section class="panel"><div class="section-heading"><div><p class="eyebrow">RECENT ACTIVITY</p><h2>Your latest orders</h2></div><a href="/orders">All orders</a></div>' . order_table($recent, false) . '</section>';
    page('Dashboard', $body, $user);
}

function order_table(array $rows, bool $showUser): string
{
    if (!$rows) return '<div class="empty-state">Nothing to show yet.</div>';
    $html = '<div class="table-wrap"><table><thead><tr><th>Order</th>' . ($showUser ? '<th>Customer</th>' : '') . '<th>Service</th><th>Amount</th><th>Status</th><th>Created</th></tr></thead><tbody>';
    foreach ($rows as $r) {
        $html .= '<tr><td><a href="/orders/' . e((string) $r['id']) . '">#' . e((string) $r['public_id']) . '</a></td>' . ($showUser ? '<td>' . e((string) ($r['email'] ?? '')) . '</td>' : '') . '<td>' . e((string) ($r['service_name'] ?? 'Service')) . '</td><td>' . e(money((int) $r['total_minor'], (string) $r['currency'])) . '</td><td>' . pill((string) $r['status']) . '</td><td>' . e((string) $r['created_at']) . '</td></tr>';
    }
    return $html . '</tbody></table></div>';
}

function render_services(PDO $db, array $user): void
{
    $rows = query_rows($db, 'SELECT id,name,category,description,unit_price_minor,currency FROM services WHERE active=1 ORDER BY category,name');
    $html = heading('SERVICE CATALOG','Reviewed services','Services are reviewed before publication and delivered by people.') . '<div class="service-grid">';
    foreach ($rows as $r) {
        $html .= '<article class="service-card"><span class="tag">' . e($r['category']) . '</span><h2>' . e($r['name']) . '</h2><p>' . nl2br(e($r['description'])) . '</p><div class="service-bottom"><strong>' . e(money((int) $r['unit_price_minor'], (string) $r['currency'])) . '<small> per unit</small></strong><a class="button button-primary" href="/services/' . e((string) $r['id']) . '">View details</a></div></article>';
    }
    if (!$rows) $html .= '<div class="empty-state">No services are available yet.</div>';
    $html .= '</div>';
    page('Services', $html, $user);
}

function render_service(PDO $db, array $user, int $id, string $error = ''): void
{
    $r = query_rows($db, 'SELECT id,name,category,description,unit_price_minor,currency FROM services WHERE id=? AND active=1', [$id])[0] ?? null;
    if (!$r) { http_response_code(404); page('Service not found', heading('CATALOG','Service not found','This service is unavailable.'), $user); return; }
    $body = heading(e($r['category']),'Place an order','Review the details and confirm your quantity.') . ($error ? '<div class="notice notice-error">' . e($error) . '</div>' : '') . '<section class="panel order-form-panel"><div><h2>' . e($r['name']) . '</h2><p>' . nl2br(e($r['description'])) . '</p><p class="price-large">' . e(money((int) $r['unit_price_minor'], (string) $r['currency'])) . ' <small>per unit</small></p><p class="muted">Available balance: ' . e(money(Domain::balance($db,(int)$user['id']))) . ' · <a href="/wallet">Manage balance</a></p></div><div>' . form_start('/orders/create') . '<input type="hidden" name="service_id" value="' . e((string) $r['id']) . '"><input type="hidden" name="_key" value="' . e(bin2hex(random_bytes(24))) . '"><label>Quantity<input type="number" name="quantity" min="1" max="100000" value="1" required></label><label>Requirements or delivery notes<textarea name="details" rows="5" maxlength="1500" placeholder="Describe the agreed deliverable"></textarea></label><button class="button button-primary" type="submit">Place order</button><p class="form-note">Placing an order charges your account balance. No external platform automation is involved.</p></form></div></section>';
    page('Place order', $body, $user);
}

function render_orders(PDO $db, array $user): void
{
    $rows = query_rows($db, 'SELECT o.id,o.public_id,o.status,o.total_minor,o.currency,o.created_at,s.name service_name FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 100', [(int) $user['id']]);
    page('Orders', heading('ORDER HISTORY','Your orders','Follow every order from submission through completion.') . '<section class="panel">' . order_table($rows,false) . '</section>', $user);
}

function render_order_detail(PDO $db, array $user, int $id): void
{
    $r = query_rows($db, 'SELECT o.*,s.name service_name FROM orders o JOIN services s ON s.id=o.service_id WHERE o.id=? AND o.user_id=?', [$id,(int)$user['id']])[0] ?? null;
    if (!$r) { http_response_code(404); page('Order not found',heading('ORDER','Order not found'),$user); return; }
    $body = heading('ORDER DETAIL','Order #' . $r['public_id'],'Current status ' . str_replace('_',' ',$r['status'])) . '<section class="panel detail-grid"><div><span class="eyebrow">SERVICE</span><h2>' . e($r['service_name']) . '</h2><p>' . nl2br(e($r['details'])) . '</p></div><div><span class="eyebrow">ORDER SUMMARY</span><p>Quantity: <strong>' . e((string)$r['quantity']) . '</strong></p><p>Total: <strong>' . e(money((int)$r['total_minor'],$r['currency'])) . '</strong></p><p>Status: ' . pill($r['status']) . '</p><p class="muted">Created ' . e($r['created_at']) . '</p></div></section>';
    page('Order detail',$body,$user);
}

function render_wallet(PDO $db, array $user): void
{
    $uid=(int)$user['id']; $rows=query_rows($db,'SELECT type,amount_minor,currency,reference,note,created_at FROM ledger_transactions WHERE user_id=? ORDER BY id DESC LIMIT 100',[$uid]);
    $body=heading('WALLET','Balance & transactions','Deposit requests are manually reviewed outside this app; no payment is sent here.') . '<div class="metric-grid"><article class="metric-card"><span>Available balance</span><strong>' . e(money(Domain::balance($db,$uid))) . '</strong><a href="#deposit">Request a balance review →</a></article><article class="metric-card"><span>Ledger entries</span><strong>' . e((string)count($rows)) . '</strong><span>Latest 100 entries</span></article></div><section class="panel" id="deposit"><div class="section-heading"><div><p class="eyebrow">MANUAL REVIEW</p><h2>Request a deposit</h2></div></div><p class="muted">This creates a pending request only. An authorized finance reviewer must verify receipt externally before approval.</p>' . form_start('/wallet/deposit','inline-form') . '<label>Amount in UZS<input type="number" name="amount" min="100" max="50000000" step="1" required></label><label>Note (optional)<input name="note" maxlength="500"></label><input type="hidden" name="_key" value="' . e(bin2hex(random_bytes(24))) . '"><button class="button button-primary" type="submit">Submit request</button></form></section><section class="panel"><div class="section-heading"><div><p class="eyebrow">ACCOUNTING</p><h2>Transaction history</h2></div></div>' . ledger_table($rows) . '</section>';
    page('Wallet',$body,$user);
}

function ledger_table(array $rows, bool $withEmail=false): string
{
    if (!$rows) return '<div class="empty-state">No transactions yet.</div>';
    $html='<div class="table-wrap"><table><thead><tr><th>Type</th>' . ($withEmail?'<th>Account</th>':'') . '<th>Amount</th><th>Reference</th><th>Note</th><th>Date</th></tr></thead><tbody>';
    foreach($rows as $r) $html.='<tr><td>' . e($r['type']) . '</td>' . ($withEmail?'<td>' . e($r['email']) . '</td>':'') . '<td class="' . ((int)$r['amount_minor']<0?'amount-negative':'amount-positive') . '">' . e(money((int)$r['amount_minor'],$r['currency'])) . '</td><td>' . e($r['reference']) . '</td><td>' . e($r['note']) . '</td><td>' . e($r['created_at']) . '</td></tr>';
    return $html . '</tbody></table></div>';
}

function render_profile(PDO $db,array $user,string $error=''): void
{
    $body=heading('ACCOUNT','Your profile','Update the name shown in your workspace.') . ($error?'<div class="notice notice-error">'.e($error).'</div>':'') . '<section class="panel auth-panel">' . form_start('/profile') . '<label>Display name<input name="display_name" maxlength="80" value="' . e($user['display_name']) . '" required></label><label>Email<input value="' . e($user['email']) . '" disabled></label><button class="button button-primary" type="submit">Save profile</button></form><p class="muted">Need to change your password? Contact support so an administrator can arrange a secure reset.</p></section>';
    page('Profile',$body,$user);
}

function render_help(PDO $db,array $user): void
{
    $rows=query_rows($db,'SELECT subject,message,status,created_at FROM support_tickets WHERE user_id=? ORDER BY id DESC LIMIT 30',[(int)$user['id']]);
    $body=heading('SUPPORT','How can we help?','Send a support request and track its status.') . '<section class="panel"><h2>New request</h2>' . form_start('/help') . '<label>Subject<input name="subject" maxlength="160" required></label><label>Message<textarea name="message" rows="5" maxlength="3000" required></textarea></label><button class="button button-primary" type="submit">Send support request</button></form></section><section class="panel"><h2>Your requests</h2>';
    if (!$rows) $body.='<div class="empty-state">You have not contacted support yet.</div>';
    else foreach($rows as $r) $body.='<article class="ticket"><div><strong>'.e($r['subject']).'</strong><p>'.nl2br(e($r['message'])).'</p><small>'.e($r['created_at']).'</small></div>'.pill($r['status']).'</article>';
    $body.='<p class="muted">Support email: <a href="mailto:' . e(setting($db,'support_email','support@example.com')) . '">' . e(setting($db,'support_email','support@example.com')) . '</a></p></section>';
    page('Help',$body,$user);
}

function render_admin(PDO $db,array $user,string $route): void
{
    $body=admin_nav();
    if($route==='/admin'){
        $counts=[]; foreach(['users','orders','services','ledger_transactions'] as $t) $counts[$t]=(int)query_value($db,'SELECT COUNT(*) FROM '.$t);
        $pending=(int)query_value($db,"SELECT COUNT(*) FROM deposit_requests WHERE status='pending'");
        $balances=(int)query_value($db,'SELECT COALESCE(SUM(balance_minor),0) FROM accounts');
        $completed=(int)query_value($db,"SELECT COALESCE(SUM(total_minor),0) FROM orders WHERE status='completed'");
        $body.=heading('CONTROL CENTER','Operations overview','Review activity and manage the service workspace.');
        $body.='<div class="metric-grid">'; foreach(['users'=>'Users','orders'=>'Orders','services'=>'Services','ledger_transactions'=>'Ledger entries'] as $k=>$label) $body.='<article class="metric-card"><span>'.e($label).'</span><strong>'.e((string)$counts[$k]).'</strong></article>'; $body.='<article class="metric-card metric-highlight"><span>Deposit requests awaiting review</span><strong>'.e((string)$pending).'</strong><a href="/admin/transactions">Review transactions →</a></article><article class="metric-card"><span>Account balances outstanding</span><strong>'.e(money($balances)).'</strong></article><article class="metric-card"><span>Completed order volume</span><strong>'.e(money($completed)).'</strong></article></div>';
        $recent=query_rows($db,'SELECT o.id,o.public_id,o.status,o.total_minor,o.currency,o.created_at,s.name service_name,u.email FROM orders o JOIN services s ON s.id=o.service_id JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 8');
        $body.='<section class="panel"><div class="section-heading"><h2>Latest orders</h2><a href="/admin/orders">All orders</a></div>'.order_table($recent,true).'</section>';
    } elseif($route==='/admin/users'){
        $roleAgg=$db->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql' ? 'GROUP_CONCAT(r.name SEPARATOR ", ")' : 'GROUP_CONCAT(r.name, ", ")';
        $search=trim((string)($_GET['q']??'')); if(mb_strlen($search)>100)$search=mb_substr($search,0,100); $pattern='%'.$search.'%';
        $users=query_rows($db,'SELECT u.id,u.email,u.display_name,u.status,u.created_at,a.balance_minor,'.$roleAgg.' roles FROM users u LEFT JOIN accounts a ON a.user_id=u.id LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id WHERE (? = \'\' OR u.email LIKE ? OR u.display_name LIKE ?) GROUP BY u.id ORDER BY u.id DESC LIMIT 200',[$search,$pattern,$pattern]);
        $body.=heading('ACCESS','Users','Review account status, roles and account adjustments.') . '<section class="panel"><form method="get" action="/admin/users" class="inline-form filter-form"><label>Search by name or email<input name="q" value="'.e($search).'" maxlength="100"></label><button class="button button-quiet" type="submit">Search users</button></form>';
        $body.='<div class="table-wrap"><table><thead><tr><th>User</th><th>Status</th><th>Roles</th><th>Balance</th><th>Role assignment</th><th>Balance adjustment</th></tr></thead><tbody>';
        foreach($users as $u){$body.='<tr><td><strong>'.e($u['display_name']).'</strong><small class="block">'.e($u['email']).'</small></td><td>'.pill($u['status']).'<form method="post" action="/admin/user/status">'.csrf_field().'<input type="hidden" name="user_id" value="'.e($u['id']).'"><input type="hidden" name="status" value="'.($u['status']==='active'?'suspended':'active').'"><button class="small-button" type="submit">'.($u['status']==='active'?'Suspend':'Activate').'</button></form></td><td>'.e($u['roles']??'').'</td><td>'.e(money((int)$u['balance_minor'])).'</td><td><form method="post" action="/admin/user/role" class="stack-form">'.csrf_field().'<input type="hidden" name="user_id" value="'.e($u['id']).'"><select name="role" required><option value="">Choose role</option><option>admin</option><option>finance</option><option>support</option><option>user</option></select><button class="small-button" type="submit">Assign</button></form></td><td><form method="post" action="/admin/user/adjust" class="stack-form">'.csrf_field().'<input type="hidden" name="user_id" value="'.e($u['id']).'"><input name="amount" type="number" step="1" min="-50000000" max="50000000" placeholder="UZS +/-" required><input name="reason" maxlength="500" placeholder="Reason" required><input type="hidden" name="_key" value="'.e(bin2hex(random_bytes(24))).'"><button class="small-button" type="submit">Apply</button></form></td></tr>';}
        $body.='</tbody></table></div></section>';
    } elseif($route==='/admin/orders'){
        $status=(string)($_GET['status']??''); if(!in_array($status,['','pending','in_progress','completed','canceled'],true))$status='';
        $rows=query_rows($db,'SELECT o.id,o.public_id,o.status,o.total_minor,o.currency,o.created_at,s.name service_name,u.email FROM orders o JOIN services s ON s.id=o.service_id JOIN users u ON u.id=o.user_id WHERE (? = \'\' OR o.status = ?) ORDER BY o.id DESC LIMIT 200',[$status,$status]);
        $body.=heading('FULFILLMENT','Orders','Update order progress after reviewing delivery status.') . '<section class="panel"><form method="get" action="/admin/orders" class="inline-form filter-form"><label>Filter by status<select name="status"><option value="">All statuses</option><option value="pending" '.($status==='pending'?'selected':'').'>Pending</option><option value="in_progress" '.($status==='in_progress'?'selected':'').'>In progress</option><option value="completed" '.($status==='completed'?'selected':'').'>Completed</option><option value="canceled" '.($status==='canceled'?'selected':'').'>Canceled</option></select></label><button class="button button-quiet" type="submit">Filter orders</button></form>'.order_table($rows,true).'<div class="admin-action-list">';
        foreach($rows as $r){$body.='<form method="post" action="/admin/order/status" class="inline-form">'.csrf_field().'<input type="hidden" name="order_id" value="'.e($r['id']).'"><span>#'.e($r['public_id']).'</span><select name="status"><option '.($r['status']==='pending'?'selected':'').'>pending</option><option value="in_progress" '.($r['status']==='in_progress'?'selected':'').'>in progress</option><option '.($r['status']==='completed'?'selected':'').'>completed</option><option '.($r['status']==='canceled'?'selected':'').'>canceled</option></select><button class="small-button">Save status</button></form>';}
        $body.='</div></section>';
    } elseif($route==='/admin/transactions'){
        $requests=query_rows($db,'SELECT d.*,u.email FROM deposit_requests d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 100');
        $body.=heading('FINANCE','Transactions & requests','Ledger entries are immutable. Approve requests only after external receipt verification.') . '<section class="panel"><h2>Deposit requests</h2>';
        if(!$requests)$body.='<div class="empty-state">No deposit requests yet.</div>';
        foreach($requests as $d){$body.='<article class="review-row"><div><strong>'.e($d['email']).'</strong><p>'.e(money((int)$d['amount_minor'],$d['currency'])).' · '.e($d['user_note']).'</p><small>'.e($d['created_at']).' · '.pill($d['status']).'</small></div>'; if($d['status']==='pending') $body.='<div class="button-row"><form method="post" action="/admin/deposit/approve">'.csrf_field().'<input type="hidden" name="request_id" value="'.e($d['id']).'"><button class="button button-primary">Mark verified & approve</button></form><form method="post" action="/admin/deposit/reject">'.csrf_field().'<input type="hidden" name="request_id" value="'.e($d['id']).'"><input name="note" maxlength="500" placeholder="Reason (optional)"><button class="button button-quiet">Reject</button></form></div>'; $body.='</article>';}
        $ledger=query_rows($db,'SELECT l.*,u.email FROM ledger_transactions l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 100');
        $body.='</section><section class="panel"><h2>Recent ledger entries</h2>'.ledger_table($ledger,true).'</section>';
    } elseif($route==='/admin/services'){
        $services=query_rows($db,'SELECT * FROM services ORDER BY id DESC');
        $body.=heading('CATALOG','Manage services','Only reviewed, lawful human-delivered services may be listed.') . '<section class="panel"><h2>Add a service</h2>' . form_start('/admin/services/create','service-form') . '<label>Name<input name="name" maxlength="100" required></label><label>Category<select name="category" required>'; foreach(Domain::categories() as $cat)$body.='<option>'.e($cat).'</option>'; $body.='</select></label><label>Unit price in UZS<input type="number" name="price" min="1" max="1000000000" step="1" required></label><label class="wide">Description<textarea name="description" maxlength="2000" rows="3"></textarea></label><button class="button button-primary">Publish reviewed service</button></form></section><section class="panel"><h2>Current catalog</h2><div class="table-wrap"><table><thead><tr><th>Service</th><th>Category</th><th>Price</th><th>Status</th><th>Action</th></tr></thead><tbody>';
        foreach($services as $s){
            $formId='service-edit-'.(int)$s['id'];
            $body.='<tr><td><form id="'.e($formId).'" method="post" action="/admin/services/update" class="stack-form">'.csrf_field().'<input type="hidden" name="service_id" value="'.e($s['id']).'"><input name="name" maxlength="100" value="'.e($s['name']).'" required></form></td><td><select form="'.e($formId).'" name="category" required>';
            foreach(Domain::categories() as $cat)$body.='<option value="'.e($cat).'" '.($s['category']===$cat?'selected':'').'>'.e($cat).'</option>';
            $body.='</select></td><td><input form="'.e($formId).'" name="price" type="number" min="1" max="1000000000" step="1" value="'.e((string)intdiv((int)$s['unit_price_minor'],100)).'" required></td><td>'.pill($s['active']?'active':'paused').'</td><td><button class="small-button" type="submit" form="'.e($formId).'">Save</button><form method="post" action="/admin/services/toggle" class="toggle-form">'.csrf_field().'<input type="hidden" name="service_id" value="'.e($s['id']).'"><input type="hidden" name="active" value="'.($s['active']?0:1).'"><button class="small-button">'.($s['active']?'Pause':'Activate').'</button></form></td></tr><tr class="service-description-row"><td colspan="5"><label>Description<textarea form="'.e($formId).'" name="description" maxlength="2000" rows="2">'.e($s['description']).'</textarea></label></td></tr>';
        }
        $body.='</tbody></table></div></section>';
    } elseif($route==='/admin/support'){
        $tickets=query_rows($db,'SELECT t.*,u.email FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 200');
        $body.=heading('CUSTOMER CARE','Support requests','Review and update customer support tickets.') . '<section class="panel">';
        if(!$tickets)$body.='<div class="empty-state">No support requests yet.</div>';
        foreach($tickets as $t){$body.='<article class="review-row"><div><strong>'.e($t['subject']).'</strong><p>'.nl2br(e($t['message'])).'</p><small>'.e($t['email']).' · '.e($t['created_at']).' · '.pill($t['status']).'</small></div><form method="post" action="/admin/ticket/status">'.csrf_field().'<input type="hidden" name="ticket_id" value="'.e($t['id']).'"><select name="status"><option value="open" '.($t['status']==='open'?'selected':'').'>Open</option><option value="in_progress" '.($t['status']==='in_progress'?'selected':'').'>In progress</option><option value="closed" '.($t['status']==='closed'?'selected':'').'>Closed</option></select><button class="small-button">Save</button></form></article>'; }
        $body.='</section>';
    } elseif($route==='/admin/settings'){
        $body.=heading('WORKSPACE','Settings','Manage public registration and support contact details.') . '<section class="panel auth-panel">' . form_start('/admin/settings') . '<label>Registration<select name="registration_open"><option value="1" '.(setting($db,'registration_open','1')==='1'?'selected':'').'>Open</option><option value="0" '.(setting($db,'registration_open','1')==='0'?'selected':'').'>Closed</option></select></label><label>Support email<input type="email" name="support_email" maxlength="190" value="'.e(setting($db,'support_email','support@example.com')).'" required></label><button class="button button-primary">Save settings</button></form></section>';
    } elseif($route==='/admin/logs'){
        $logs=query_rows($db,'SELECT a.*,u.email FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 200');
        $body.=heading('AUDIT TRAIL','Activity logs','Administrative and account actions recorded by the application.') . '<section class="panel"><div class="table-wrap"><table><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead><tbody>';
        foreach($logs as $l)$body.='<tr><td>'.e($l['created_at']).'</td><td>'.e($l['email']??'system').'</td><td>'.e($l['action']).'</td><td>'.e($l['entity_type'].' #'.($l['entity_id']??'')).'</td><td><code>'.e($l['metadata_json']).'</code></td></tr>';
        $body.='</tbody></table></div></section>';
    } elseif($route==='/admin/roles'){
        $roles=query_rows($db,'SELECT r.name,r.label,COUNT(ur.user_id) members FROM roles r LEFT JOIN user_roles ur ON ur.role_id=r.id GROUP BY r.id ORDER BY r.id');
        $body.=heading('PERMISSIONS','Roles','Fixed application roles gate every administrative action.') . '<section class="panel"><div class="table-wrap"><table><thead><tr><th>Role</th><th>Purpose</th><th>Members</th></tr></thead><tbody>';
        foreach($roles as $r)$body.='<tr><td>'.e($r['name']).'</td><td>'.e($r['label']).'</td><td>'.e((string)$r['members']).'</td></tr>';
        $body.='</tbody></table></div><p class="muted">The owner role is assigned only through the first-owner CLI bootstrap. User role changes are restricted to owners.</p></section>';
    }
    page('Administration',$body,$user);
}
