<?php
declare(strict_types=1);
$root = dirname(__DIR__);
require_once $root . '/src/Config.php';
Config::load($root);
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => Config::bool('SESSION_SECURE', false),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header("Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; img-src 'self' data:; style-src 'self'");
require_once $root . '/src/Database.php';
require_once $root . '/src/Security.php';
require_once $root . '/src/Auth.php';
require_once $root . '/src/Domain.php';
require_once $root . '/src/Pages.php';
$db = Database::connect();
