<?php
declare(strict_types=1);

final class Auth
{
    public static function current(PDO $db): ?array
    {
        $id = filter_var($_SESSION['user_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id) {
            return null;
        }
        $stmt = $db->prepare('SELECT id, email, display_name, status, created_at FROM users WHERE id = ?');
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        if (!$user || $user['status'] !== 'active') {
            unset($_SESSION['user_id']);
            return null;
        }
        $roleStmt = $db->prepare('SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id = r.id WHERE ur.user_id = ?');
        $roleStmt->execute([$id]);
        $user['roles'] = array_column($roleStmt->fetchAll(), 'name');
        return $user;
    }

    public static function hasAnyRole(array $user, array $roles): bool
    {
        return (bool) array_intersect($roles, $user['roles'] ?? []);
    }

    public static function requireLogin(?array $user): array
    {
        if ($user === null) {
            flash('warning', 'Sign in to continue.');
            redirect('/login');
        }
        return $user;
    }

    public static function requireRole(?array $user, array $roles): array
    {
        $user = self::requireLogin($user);
        if (!self::hasAnyRole($user, $roles)) {
            http_response_code(403);
            page('Access denied', '<section class="panel narrow"><p class="eyebrow">403</p><h1>Access denied</h1><p class="muted">Your account does not have permission for this action.</p></section>', $user);
            exit;
        }
        return $user;
    }

    public static function register(PDO $db, string $email, string $displayName, string $password): int
    {
        $email = mb_strtolower(trim($email));
        $displayName = trim($displayName);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            throw new DomainException('Enter a valid email address.');
        }
        if ($displayName === '' || mb_strlen($displayName) > 80) {
            throw new DomainException('Name must be between 1 and 80 characters.');
        }
        if (strlen($password) < 12 || strlen($password) > 200) {
            throw new DomainException('Use a password between 12 and 200 characters.');
        }
        $db->beginTransaction();
        try {
            $stmt = $db->prepare('INSERT INTO users (email, password_hash, display_name, status, created_at, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
            $stmt->execute([$email, password_hash($password, PASSWORD_DEFAULT), $displayName, 'active']);
            $id = (int) $db->lastInsertId();
            $role = $db->prepare('SELECT id FROM roles WHERE name = ?');
            $role->execute(['user']);
            $roleId = $role->fetchColumn();
            $assign = $db->prepare('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)');
            $assign->execute([$id, (int) $roleId]);
            $account = $db->prepare('INSERT INTO accounts (user_id, balance_minor, currency) VALUES (?, 0, ?)');
            $account->execute([$id, 'UZS']);
            $db->commit();
            return $id;
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($e instanceof PDOException && str_contains(strtolower($e->getMessage()), 'unique')) {
                throw new DomainException('An account with that email already exists.');
            }
            throw $e;
        }
    }

    public static function login(PDO $db, string $email, string $password, string $ip): ?int
    {
        $email = mb_strtolower(trim($email));
        $identity = hash('sha256', $email . '|' . $ip);
        $db->prepare('DELETE FROM login_attempts WHERE attempted_at < ' . (self::isSqlite($db) ? "datetime('now', '-1 day')" : 'DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY)'))->execute();
        $count = $db->prepare('SELECT COUNT(*) FROM login_attempts WHERE identity_hash = ? AND attempted_at >= ' . (self::isSqlite($db) ? "datetime('now', '-15 minutes')" : 'DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 15 MINUTE)'));
        $count->execute([$identity]);
        if ((int) $count->fetchColumn() >= 8) {
            return null;
        }
        $stmt = $db->prepare('SELECT id, password_hash, status FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        $passwordLengthOk = strlen($password) <= 200;
        static $dummyHash = null;
        $dummyHash ??= password_hash('invalid-login-placeholder', PASSWORD_DEFAULT);
        $passwordOk = password_verify($passwordLengthOk ? $password : '', $row['password_hash'] ?? $dummyHash);
        if (!$row || $row['status'] !== 'active' || !$passwordLengthOk || !$passwordOk) {
            $fail = $db->prepare('INSERT INTO login_attempts (identity_hash, attempted_at) VALUES (?, CURRENT_TIMESTAMP)');
            $fail->execute([$identity]);
            return null;
        }
        $clear = $db->prepare('DELETE FROM login_attempts WHERE identity_hash = ?');
        $clear->execute([$identity]);
        session_regenerate_id(true);
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        $_SESSION['user_id'] = (int) $row['id'];
        return (int) $row['id'];
    }

    private static function isSqlite(PDO $db): bool
    {
        return $db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
    }
}
