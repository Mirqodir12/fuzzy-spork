<?php
declare(strict_types=1);
$root=dirname(__DIR__);$dbFile=$root.'/storage/test.sqlite';$testUsersFile=$root.'/storage/test-users.json';
if(!function_exists('curl_init')||!is_file($dbFile)||!is_file($testUsersFile)){fwrite(STDERR,"HTTP smoke requires curl and tests/run.php first.\n");exit(2);}
$testUsers=json_decode(file_get_contents($testUsersFile),true,512,JSON_THROW_ON_ERROR);
$db=new PDO('sqlite:'.$dbFile);$service=(int)$db->query("SELECT id FROM services WHERE name='Editorial illustration' ORDER BY id LIMIT 1")->fetchColumn();
$nonce=bin2hex(random_bytes(6));$jar=sys_get_temp_dir().'/funyapi-http-'.$nonce.'.cookies';$checks=0;
function req(string $path,string $method='GET',array $data=[]):array{global $jar;$c=curl_init('http://127.0.0.1:8099'.$path);curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>true,CURLOPT_COOKIEJAR=>$jar,CURLOPT_COOKIEFILE=>$jar,CURLOPT_TIMEOUT=>5]);if($method==='POST'){curl_setopt($c,CURLOPT_POST,true);curl_setopt($c,CURLOPT_POSTFIELDS,http_build_query($data));}$raw=curl_exec($c);if($raw===false){$err=curl_error($c);curl_close($c);throw new RuntimeException($err);} $status=(int)curl_getinfo($c,CURLINFO_RESPONSE_CODE);$size=(int)curl_getinfo($c,CURLINFO_HEADER_SIZE);curl_close($c);return ['status'=>$status,'headers'=>substr($raw,0,$size),'body'=>substr($raw,$size)];}
function assert_http(bool $ok,string $message):void{global $checks;$checks++;if(!$ok){fwrite(STDERR,"FAIL: {$message}\n");exit(1);}fwrite(STDOUT,"PASS: {$message}\n");}
function token(string $body):string{if(!preg_match('/name="_csrf" value="([a-f0-9]+)"/',$body,$m))throw new RuntimeException('CSRF token not found');return $m[1];}
function login_as(string $email,string $password):void{$page=req('/login');assert_http($page['status']===200,'login page loads');$result=req('/login','POST',['_csrf'=>token($page['body']),'email'=>$email,'password'=>$password]);assert_http($result['status']===303,'login form posts successfully for '.$email);}
try{
@unlink($jar);
login_as('owner@example.test',$testUsers['owner_password']);$ownerJar=$jar;
foreach(['/','/services','/orders','/wallet','/profile','/help','/admin','/admin/users','/admin/orders','/admin/transactions','/admin/services','/admin/support','/admin/settings','/admin/logs','/admin/roles'] as $url){$r=req($url);assert_http($r['status']===200,'page returns 200: '.$url);}
assert_http(req('/admin/users?q=customer%40example.test')['status']===200,'user search filter reaches prepared query');
assert_http(req('/admin/orders?status=pending')['status']===200,'order status filter reaches prepared query');
$bad=req('/admin/user/status','POST',['user_id'=>2,'status'=>'suspended']);assert_http($bad['status']===419,'state-changing POST without CSRF token is rejected');
$services=req('/admin/services');$create=req('/admin/services/create','POST',['_csrf'=>token($services['body']),'name'=>'HTTP test design review','category'=>'Consulting','description'=>'Human-led review','price'=>'90']);assert_http($create['status']===303,'admin service create button reaches backend');
$services=req('/admin/services');$edit=req('/admin/services/update','POST',['_csrf'=>token($services['body']),'service_id'=>$service,'name'=>'Editorial illustration','category'=>'Design','description'=>'Updated human-created artwork','price'=>'125']);assert_http($edit['status']===303,'admin service edit button updates catalog details and price');
$customerJar=sys_get_temp_dir().'/funyapi-http-customer-'.$nonce.'.cookies';$jar=$customerJar;login_as('customer@example.test',$testUsers['customer_password']);
foreach(['/','/services','/orders','/wallet','/profile','/help'] as $url){$r=req($url);assert_http($r['status']===200,'customer page returns 200: '.$url);}
$denied=req('/admin/users');assert_http($denied['status']===403,'customer cannot access admin user management');
$servicePage=req('/services/'.$service);$formToken=token($servicePage['body']);preg_match('/name="_key" value="([a-f0-9]+)"/',$servicePage['body'],$keyMatch);$placed=req('/orders/create','POST',['_csrf'=>$formToken,'_key'=>$keyMatch[1]??'','service_id'=>$service,'quantity'=>1,'details'=>'HTTP end-to-end order']);assert_http($placed['status']===303,'customer order button reaches balance-checked backend');
preg_match('#Location:\s*(/orders/\d+)#i',$placed['headers'],$location);assert_http(isset($location[1])&&req($location[1])['status']===200,'new order detail page is available to its owner');
$wallet=req('/wallet');preg_match('/name="_key" value="([a-f0-9]+)"/',$wallet['body'],$depositKey);$deposit=req('/wallet/deposit','POST',['_csrf'=>token($wallet['body']),'_key'=>$depositKey[1]??'','amount'=>'100','note'=>'HTTP smoke deposit']);assert_http($deposit['status']===303,'wallet deposit request button creates manual review request');
$jar=$ownerJar;
$tx=req('/admin/transactions');preg_match('/name="request_id" value="(\d+)"/',$tx['body'],$requestId);$approve=req('/admin/deposit/approve','POST',['_csrf'=>token($tx['body']),'request_id'=>$requestId[1]??'']);assert_http($approve['status']===303,'finance approve button reaches manual-review backend');
$adminOrders=req('/admin/orders');preg_match('#/orders/(\d+)#',$placed['headers'],$orderId);$change=req('/admin/order/status','POST',['_csrf'=>token($adminOrders['body']),'order_id'=>$orderId[1]??'','status'=>'completed']);assert_http($change['status']===303,'admin order status button persists a transition');
$help=req('/admin/support');$ticket=req('/admin/ticket/status','POST',['_csrf'=>token($help['body']),'ticket_id'=>'1','status'=>'closed']);assert_http($ticket['status']===303,'support ticket status button reaches backend');
$serviceAdmin=req('/admin/services');$toggle=req('/admin/services/toggle','POST',['_csrf'=>token($serviceAdmin['body']),'service_id'=>$service,'active'=>'0']);assert_http($toggle['status']===303,'service pause button reaches backend');
$serviceAdmin=req('/admin/services');$toggle=req('/admin/services/toggle','POST',['_csrf'=>token($serviceAdmin['body']),'service_id'=>$service,'active'=>'1']);assert_http($toggle['status']===303,'service activate button reaches backend');
$settings=req('/admin/settings');$save=req('/admin/settings','POST',['_csrf'=>token($settings['body']),'registration_open'=>'1','support_email'=>'support@example.test']);assert_http($save['status']===303,'settings form persists through a prepared upsert');
$users=req('/admin/users');$assign=req('/admin/user/role','POST',['_csrf'=>token($users['body']),'user_id'=>'2','role'=>'support']);assert_http($assign['status']===303,'owner role assignment button reaches backend');
$users=req('/admin/users');$adjustKey=[];preg_match('#<form method="post" action="/admin/user/adjust" class="stack-form">.*?name="user_id" value="2".*?name="_key" value="([a-f0-9]+)"#s',$users['body'],$adjustKey);$adjust=req('/admin/user/adjust','POST',['_csrf'=>token($users['body']),'user_id'=>'2','amount'=>'25','reason'=>'HTTP smoke adjustment','_key'=>$adjustKey[1]??bin2hex(random_bytes(24))]);assert_http($adjust['status']===303,'finance balance adjustment is ledger-backed');
$users=req('/admin/users');$suspend=req('/admin/user/status','POST',['_csrf'=>token($users['body']),'user_id'=>'2','status'=>'suspended']);assert_http($suspend['status']===303,'user suspend action reaches backend');
$users=req('/admin/users');$activate=req('/admin/user/status','POST',['_csrf'=>token($users['body']),'user_id'=>'2','status'=>'active']);assert_http($activate['status']===303,'user activate action reaches backend');
} finally {@unlink($jar);@unlink($ownerJar??'');@unlink(sys_get_temp_dir().'/funyapi-http-customer-'.$nonce.'.cookies');@unlink($testUsersFile);}
fwrite(STDOUT,"{$checks} HTTP checks passed.\n");
