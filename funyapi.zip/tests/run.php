<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$testDb=$root.'/storage/test.sqlite';
if(is_file($testDb)) unlink($testDb); // This path is a disposable test database inside this generated app only.
putenv('APP_ENV=test'); putenv('APP_DSN=sqlite:'.$testDb); putenv('DB_USER='); putenv('DB_PASSWORD=');
require $root.'/src/Config.php'; Config::load($root);
require $root.'/src/Security.php'; require $root.'/src/Database.php'; require $root.'/src/Auth.php'; require $root.'/src/Domain.php'; require $root.'/src/Pages.php';
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
$db=new PDO('sqlite:'.$testDb,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$db->exec('PRAGMA foreign_keys=ON');
$db->exec(file_get_contents($root.'/database/migrations/sqlite/001_initial.sql'));
$checks=0;
function check(bool $ok,string $message):void{global $checks;$checks++;if(!$ok){fwrite(STDERR,"FAIL: {$message}\n");exit(1);}fwrite(STDOUT,"PASS: {$message}\n");}
$testUsers=['owner_password'=>bin2hex(random_bytes(24)),'customer_password'=>bin2hex(random_bytes(24))];
file_put_contents($root.'/storage/test-users.json',json_encode($testUsers,JSON_THROW_ON_ERROR));
$owner=Auth::register($db,'owner@example.test','Test Owner',$testUsers['owner_password']);
$db->prepare('INSERT INTO user_roles(user_id,role_id) SELECT ?,id FROM roles WHERE name=?')->execute([$owner,'owner']);
$customer=Auth::register($db,'customer@example.test','Test Customer',$testUsers['customer_password']);
check(Auth::hasAnyRole(Auth::current($db)??['roles'=>['owner']],['owner']),'owner role membership can be evaluated');
check(!Auth::hasAnyRole(['roles'=>['user']],['owner','finance']),'ordinary user is outside finance/admin roles');
$svc=Domain::createService($db,['name'=>'Editorial illustration','category'=>'Design','description'=>'Human-created campaign artwork.','unit_price_minor'=>12500],$owner);
check($svc>0,'reviewed service can be created');
Domain::updateService($db,$svc,['name'=>'Editorial illustration','category'=>'Design','description'=>'Human-created campaign artwork, updated.','unit_price_minor'=>12500],$owner);check(query_value($db,'SELECT description FROM services WHERE id=?',[$svc])==='Human-created campaign artwork, updated.','admin service edit persists validated fields and price');
$balanceKey=bin2hex(random_bytes(24));Domain::adjustBalance($db,$customer,100000,'Test funding for order coverage',$owner,$balanceKey);
$fundedBalance=Domain::balance($db,$customer);Domain::adjustBalance($db,$customer,100000,'Duplicate funding request',$owner,$balanceKey);check(Domain::balance($db,$customer)===$fundedBalance,'duplicate admin adjustment rolls back without changing balance');
$before=Domain::balance($db,$customer);$orderKey=bin2hex(random_bytes(24));$order=Domain::placeOrder($db,$customer,$svc,2,'Create two draft concepts',$orderKey);$again=Domain::placeOrder($db,$customer,$svc,2,'Create two draft concepts',$orderKey);
check($order===$again,'order idempotency returns the original order');
check(Domain::balance($db,$customer)===$before-25000,'duplicate order submission debits only once');
$ledgerCount=(int)$db->query('SELECT COUNT(*) FROM ledger_transactions')->fetchColumn();check($ledgerCount===2,'order charge and funding adjustment have one ledger row each');
$pendingKey=bin2hex(random_bytes(24));Domain::requestDeposit($db,$customer,15000,'Pending request for UI test',$pendingKey);
$depKey=bin2hex(random_bytes(24));$dep=Domain::requestDeposit($db,$customer,20000,'Offline transfer reference',$depKey);$depAgain=Domain::requestDeposit($db,$customer,20000,'Offline transfer reference',$depKey);check($dep===$depAgain,'deposit request idempotency returns the original request');
$afterOrder=Domain::balance($db,$customer);Domain::approveDeposit($db,$dep,$owner);Domain::approveDeposit($db,$dep,$owner);check(Domain::balance($db,$customer)===$afterOrder+20000,'deposit approval credits at most once');
check((int)$db->query("SELECT COUNT(*) FROM ledger_transactions WHERE reference='deposit:{$dep}'")->fetchColumn()===1,'deposit has one unique accounting ledger entry');
Domain::changeOrderStatus($db,$order,'in_progress',$owner);check(query_value($db,'SELECT status FROM orders WHERE id=?',[$order])==='in_progress','order status transition is persisted');
try{Domain::createService($db,['name'=>'Followers package','category'=>'Other reviewed service','description'=>'No','unit_price_minor'=>10000],$owner);check(false,'blocked service category wording is rejected');}catch(DomainException){check(true,'blocked engagement automation wording is rejected');}
$xss=Domain::createService($db,['name'=>'<img src=x onerror=alert(1)>','category'=>'Design','description'=>'A safe description','unit_price_minor'=>5000],$owner);ob_start();render_services($db,Auth::current($db)??['id'=>$customer,'roles'=>['user'],'display_name'=>'Test','email'=>'test@example.test']);$html=ob_get_clean();check(str_contains($html,'&lt;img src=x onerror=alert(1)&gt;')&&!str_contains($html,'<img src=x onerror=alert(1)>'),'catalog output HTML-escapes untrusted service text');
$db->prepare('INSERT INTO support_tickets(user_id,subject,message,status,created_at,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)')->execute([$customer,'Test support','Help needed','open']);
$ownerUser=Auth::current($db)??['id'=>$owner,'email'=>'owner@example.test','display_name'=>'Test Owner','roles'=>['owner']];
foreach([['wallet',fn()=>render_wallet($db,['id'=>$customer,'email'=>'customer@example.test','display_name'=>'Test Customer','roles'=>['user']]),'/wallet/deposit'],['support',fn()=>render_admin($db,$ownerUser,'/admin/support'),'/admin/ticket/status'],['services admin',fn()=>render_admin($db,$ownerUser,'/admin/services'),'/admin/services/create'],['users admin',fn()=>render_admin($db,$ownerUser,'/admin/users'),'/admin/user/adjust'],['orders admin',fn()=>render_admin($db,$ownerUser,'/admin/orders'),'/admin/order/status'],['finance admin',fn()=>render_admin($db,$ownerUser,'/admin/transactions'),'/admin/deposit/approve'],['settings admin',fn()=>render_admin($db,$ownerUser,'/admin/settings'),'/admin/settings'],['roles admin',fn()=>render_admin($db,$ownerUser,'/admin/roles'),null] ] as [$name,$render,$action]){ob_start();$render();$out=ob_get_clean();if($action===null)check(str_contains(strtolower($out),'permissions')&&str_contains($out,'owner'),'read-only roles page renders role policy');else check(str_contains($out,'action="'.$action.'"')&&str_contains($out,'name="_csrf"'),'page/button form renders for '.$name);}
check(is_file($testDb),'all integration checks used an isolated SQLite test database');
fwrite(STDOUT,"\n{$checks} checks passed. Test DB: {$testDb}\n");
