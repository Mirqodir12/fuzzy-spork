# Funy Services — xavfsiz qayta qurish

Bu paket ZIP ichidagi uzilgan Telegram botni taxmin bilan davom ettirmaydi. U alohida PHP web ilovasi: qonuniy, odamlar bajaradigan xizmatlar katalogi, buyurtmalar boshqaruvi, balans ledger’i va admin ish maydoni. Soxta ijtimoiy faollik, platforma himoyasini aylanib o‘tish, eski bot callback’lari yoki tashqi provider API’lari bu loyihaga kiritilmagan.

## Talablar

- PHP 8.2+; pdo_mysql (MySQL) yoki pdo_sqlite (faqat test), mbstring, session va openssl kengaytmalari.
- Apache’da mod_rewrite va mod_headers; document root faqat public/ papkasi bo‘lsin. Boshqa web serverda barcha ilova yo‘llarini public/index.php ga yo‘naltiring.
- Production uchun HTTPS, MySQL 8.0.16+ yoki mos MariaDB versiyasi va web-root’dan tashqarida himoyalangan .env/storage.

## Mahalliy test

1. PHP executable’ni PATH’ga qo‘shing va php -m da kerakli kengaytmalarni tekshiring. Windows’da pdo_sqlite PHP paketida bo‘lsa, buyruqqa -d extension=php_pdo_sqlite.dll qo‘shing.
2. Loyiha ildizida quyidagicha .env yarating. DSN yo‘li mutlaq bo‘lishi kerak; Windows’da sqlite:C:/full/path/to/rebuilt/storage/test.sqlite shaklidan foydalaning:

    APP_ENV=test
    APP_NAME=Funy Test
    APP_DSN=sqlite:/absolute/path/to/rebuilt/storage/test.sqlite
    SESSION_SECURE=false

3. Test sxemasini va biznes oqimlarini ishga tushiring: php tests/run.php. Windows’da: php -d extension=php_pdo_sqlite.dll tests/run.php. Test runner faqat paket ichidagi storage/test.sqlite faylini qayta yaratadi; production DB yoki arxivdagi ma’lumotlarga ulanmaydi.
4. HTTP oqimlarini sinash uchun bir terminalda php -S 127.0.0.1:8099 -t public, ikkinchisida php tests/http-smoke.php bajaring. Smoke test login, mijoz/admin sahifalari, CSRF rad etilishi, role ruxsati, xizmat yaratish, buyurtma va depozit so‘rovini SQLite nusxasida tekshiradi.
5. Alohida bo‘sh test DB’ga faqat SQLite test migratsiyasini qo‘llash uchun .env ichida APP_ENV=test va APP_DSN=sqlite:/absolute/path/to/rebuilt/storage/new-test.sqlite belgilang, so‘ng php bin/migrate-test.php bajaring. Runner mavjud DB faylini ustidan yozmaydi va storage papkasidan tashqariga yozmaydi.

## Joylashtirish tartibi

1. Avval alohida staging muhitida, production’dan ajratilgan DB nusxasi va yangi, almashtirilgan credential’lar bilan tekshiring. database/migrations/mysql/001_initial.sql faqat qayta qurilgan yangi sxema uchun; u legacy jadval/ma’lumotlarini o‘zgartirmaydi yoki ko‘chirmaydi. Disposable staging DB’ga qo‘llashdan oldin DDL’ni DBA bilan ko‘rib chiqing; keyin faqat staging nomini ko‘rsatib MySQL CLI’da import qiling:

    mysql --host=STAGING_HOST --user=STAGING_USER --password --database=STAGING_DB < database/migrations/mysql/001_initial.sql

    Parol interaktiv so‘raladi. Production database nomini bu buyruqqa kiritmang. DDL bu muhitda MySQL bilan ishga tushirilmadi, production deploy uchun tasdiqlangan deb hisoblamang.
2. RESTORATION_NOTES.md ni ko‘ring. Production DB’ga ushbu turn’da ulanilmadi va migratsiya qo‘llanmadi. Legacy user/balans/order importi mavjud emas: ZIP’da real user/order yozuvlari bo‘lmagan.
3. Ilovani faqat public/ dan serve qiling; .env ni web-root’dan tashqarida, web process o‘qiy oladigan, boshqa foydalanuvchilar o‘qiy olmaydigan ruxsatlarda saqlang. .env.example dagi DB nomi, DB user va parolni almashtiring. Eski ZIP’da oshkor bo‘lgan Telegram token(lar), DB paroli va SMS API kalitini avval bekor qiling/almashtiring; ular yangi ilova tomonidan ishlatilmaydi.
4. Staging schema va TLS sozlamalari tekshirilgandan keyingina DB konfiguratsiyasini staging/prod’ga yo‘naltiring. Bu paketda MySQL integratsion testi va prod deploy testi bajarilmagan.
5. Birinchi owner yaratish uchun staging/prod konfiguratsiyasi tayyor bo‘lgach, bir martalik himoyalangan environment’da APP_ENV=production, ALLOW_OWNER_BOOTSTRAP=YES, OWNER_EMAIL, OWNER_NAME, OWNER_PASSWORD (kamida 16 belgi) o‘rnatib php bin/create-owner.php ishga tushiriladi. Skript MySQL bo‘lmasa yoki owner mavjud bo‘lsa rad etadi; buyruqni bu audit davomida ishga tushirmadik. Tugagach bootstrap environment qiymatlarini darhol olib tashlang.
6. Admin → Settings ichida ro‘yxatdan o‘tishni va support email’ni sozlang. HTTPS ortidagi production’da SESSION_SECURE=true bo‘lishi shart.

## Funksiyalar

- Login/registration, password hashing, session ID rotation, login urinishlarini cheklash va CSRF token.
- Xizmat katalogi va admin xizmat yaratish/tahrirlash/faollashtirish.
- Idempotent buyurtma yaratish, atomar balans yechimi, foydalanuvchi buyurtmalari va admin statuslari.
- Balans, ledger tranzaksiya yozuvlari va manual review depozit so‘rovlari.
- Foydalanuvchi, support ticket, settings, audit log va fixed role paneli.
- HTML escaping, PDO prepared statements, CSP va browser security headers.

## To‘lov va tashqi servislar

Wallet formasi faqat pending manual-review so‘rov yaratadi. Ilova real pul yubormaydi/yechmaydi va Payme/Paycom yoki boshqa provayderni tekshirmaydi. Finance/admin deposit’ni faqat ilovadan tashqarida haqiqiy tushumni mustaqil tekshirganidan keyin tasdiqlashi kerak. Telegram bot va tashqi SMM/SMS provider integratsiyalari yo‘q.

## Cheklovlar

- Asl bot/bot.php ZIP’da kesilgan va qidirilgan manbalarda to‘liq nusxasi chiqmadi; bu ilova uni tiklash o‘rniga mustaqil web backend hisoblanadi.
- Testlar PHP 8.5.10, SQLite va lokal built-in serverda bajarildi. MySQL/MariaDB DDL, production web server, real to‘lov va tashqi API tekshirilmagan.
- Eski SQL’dan foydalanuvchi/balans/buyurtma migratsiyasi yo‘q. DB’da mavjud legacy ma’lumotni import qilishdan oldin alohida mapping, backup va staging rehearsal zarur.
- Xizmat matni bloklangan atamalar filtri va administrator ko‘rib chiqishiga tayanadi; katalogga qo‘shiladigan har bir xizmatni odam ko‘rib chiqishi kerak.
