# Test-only migration boundary

The SQLite migration is intended for a disposable test database only. Use bin/migrate-test.php with APP_ENV=test and a new SQLite file directly inside storage/.

The MySQL DDL is a schema draft for this rebuilt application. It has not been executed or verified against a MySQL server. Do not point it at production. Test it against a separately backed-up disposable/staging clone first.

No migration in this package imports or modifies the legacy ZIP's schema or data.
